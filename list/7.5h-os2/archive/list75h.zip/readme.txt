LIST for OS/2 1.x and above

This program runs full screen or in a text mode window under OS/2.
It is a port of Buerg's popular LIST for DOS, a text file viewer
with many helpful features.

For full documentation on LIST, refer to the documentation supplied
with the DOS version.  The DOS version can be obtained from almost
any MS-DOS archive.  The included documentation file for this OS/2
version lists the key differences between this port and the DOS
version.
